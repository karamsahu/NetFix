/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netfix;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import netfix.util.PingIP;

/**
 *
 * @author Paxcel
 */
public class NetFix extends Application {
    Button pingButton = new Button("Ping");
    Button clearButton = new Button("Clear");
    final TextArea consoleOutArea = new TextArea();

    final Text actiontarget = new Text();
    TextField ipAddressTxt = new TextField();

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage)  {
        //set window title
        primaryStage.setTitle("NetFix v0.1");
        primaryStage.show();
        
        pingButton.setOnAction(
            new EventHandler(){
                @Override
                public void handle(Event event) {
                  actiontarget.setFill(Color.FIREBRICK);
                  String ipAddress = ipAddressTxt.getText();
                    System.out.println(ipAddress);
//                  if(ipAddress.split(".").length != 3){
//                    actiontarget.setText("Invalid ip address. Please specify IP addres eg. 127.0.0.1 (localhost)");
//                    return;
//                  }
List al = new ArrayList();
                    try {
			Process p = Runtime.getRuntime().exec("ping "+ipAddress );
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(p.getInputStream()));

			String s = "";
			// reading output stream of the command
                        
			while ((s = inputStream.readLine()) != null) {
			                         System.out.println(s);
                            al.add(s);
                            consoleOutArea.appendText(s + "\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
                    System.out.println(al.toString());
                   // consoleOutArea.setText(al.toString());

//                  String pingResponse = resolveAddressToIp(ipAddress);
//                  if(!pingResponse.isEmpty()){
//                      consoleOutArea.setText(pingResponse);
//                  }
                  
                }
            }                
        );
        
        clearButton.setOnAction(
                new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    event.consume();
                    actiontarget.setText("");
                }
            }
        );
        
       
        primaryStage.setScene(createFormGrid());
        
        
        
    }
    
    private static String resolveAddressToIp(String address) {
        InetAddress inet = null;
        String response = null; 
        try {
            inet = InetAddress.getByName(address);
            response = inet.isReachable(5000) ? "Host is reachable" : "Host is NOT reachable";
        } catch (UnknownHostException ex) {
            Logger.getLogger(NetFix.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(NetFix.class.getName()).log(Level.SEVERE, null, ex);
        }
        return response;
    }
    private Scene createFormGrid() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_LEFT);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        Scene scene = new Scene(grid, 450, 150);
        //add controls e
        Text scenetitle = new Text("Welcome to Net Fix.");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
        grid.add(scenetitle, 0, 0, 2, 1);
        
        Label ipAddresLbl = new Label("IP Address : ");
        grid.add(ipAddresLbl, 0, 1);
        
        grid.add(ipAddressTxt, 1, 1);

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.CENTER_LEFT);
        hbBtn.getChildren().add(pingButton);
        grid.add(hbBtn, 3, 1);
        
        //add code to get text 
        //grid.add(actiontarget, 0, 3);
        consoleOutArea.setPrefRowCount(10);
        consoleOutArea.setPrefColumnCount(100);
        consoleOutArea.setWrapText(true);
        consoleOutArea.setPrefWidth(200);
        grid.add(consoleOutArea, 0, 3,6,1);
        grid.add(clearButton, 4 , 1);
        return scene;
    }
    
    
}
